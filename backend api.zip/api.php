<?php
header("Content-Type:application/json");
	$getData = $_GET;
	$time = $getData['time'];

	$service_url = "https://api.wheretheiss.at/v1/satellites/25544/positions?timestamps=${time}";
	$curl = curl_init($service_url);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	$curl_response = curl_exec($curl);
	if ($curl_response === false) {
	    $info = curl_getinfo($curl);
	    curl_close($curl);
	    die('error occured during curl exec. Additioanl info: ' . var_export($info));
	}
	curl_close($curl);
	$decoded = json_decode($curl_response);

	$newData = array();

	foreach ($decoded as $value) {
	  $location_url = "https://api.geoapify.com/v1/geocode/reverse?lat=" . $value->latitude . "&lon=" . $value->longitude . "&apiKey=d262c75c43904331992fa32be707738a";
		$curl2 = curl_init($location_url);
		curl_setopt($curl2, CURLOPT_RETURNTRANSFER, true);
		$curl_response2 = curl_exec($curl2);
		if ($curl_response2 === false) {
		    $info2 = curl_getinfo($curl2);
		    curl_close($curl2);
		    die('error occured during curl exec. Additioanl info: ' . var_export($info2));
		}
		curl_close($curl2);
		$decoded2 = json_decode($curl_response2);

		$weather_url = "https://api.openweathermap.org/data/2.5/onecall?lat=" . $value->latitude . "&lon=" . $value->longitude . "&appid=2e9eacfbac7533c00f933a85d1e60bee";
		$curl3 = curl_init($weather_url);
		curl_setopt($curl3, CURLOPT_RETURNTRANSFER, true);
		$curl_response3 = curl_exec($curl3);
		if ($curl_response3 === false) {
		    $info3 = curl_getinfo($curl3);
		    curl_close($curl3);
		    die('error occured during curl exec. Additioanl info: ' . var_export($info3));
		}
		curl_close($curl3);
		$decoded3 = json_decode($curl_response3);

		$obj_merged = (object) array_merge((array) $decoded2, (array) $decoded3, (array) $value);
		array_push($newData,$obj_merged);
	}

	response($newData);

function response($responses){
	$response['responses'] = $responses;

	$json_response = json_encode($response);
	echo $json_response;
}
?>
